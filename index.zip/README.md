# STUDY FORGE PHASE 11 — QUESTION BANK UPGRADE

GitHub Pages: upload `index.html` to the repository root.

## Added
- CSV import metadata: year + 基礎/応用 assigned at import time
- STUDY filters: 基礎/応用, year, subject, difficulty
- Per-question image attach / replace / delete from STUDY and BATTLE
- Images stored locally in IndexedDB; no GitHub image upload required
- Import diagnostics: detected / accepted / excluded + reasons
- Existing PHASE 10 save data is preserved
